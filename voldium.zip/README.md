# Voldium (scaffold) — Minecraft 1.21.11 Fabric

Mod add-on untuk mengurangi stutter dan meningkatkan FPS lewat:
- Throttling upload chunk mesh per frame (`MixinChunkBuilder`)
- Menyebar rebuild chunk ke beberapa tick, bukan sekaligus (`MixinClientChunkManager`)
- Frustum culling lebih ketat dengan margin lebih kecil (`MixinWorldRenderer`)
- Distance-based culling untuk entity di luar jarak tertentu (`MixinEntityRenderDispatcher`)

## ⚠️ PENTING: Sodium vs VulkanMod

**Sodium dan VulkanMod tidak bisa jalan bersamaan.** Keduanya sama-sama
menggantikan seluruh chunk/terrain rendering engine vanilla. Ini persis
sumber crash yang kamu alami sebelumnya (VulkanMod vs Mali-G57/Adreno 505).
Pilih salah satu:

- **Sodium** → aktifkan `sodiumCompat: true`, `vulkanModCompat: false` di config
- **VulkanMod** → sebaliknya

Mod ini otomatis mendeteksi mod mana yang ter-load (`VoldiumMod.java`)
dan akan mencatat error di log kalau kamu memasang keduanya sekaligus.

Catatan lain: kalau kamu pakai VulkanMod, mixin `MixinChunkBuilder` kemungkinan
besar **tidak berpengaruh**, karena VulkanMod mengganti total pipeline chunk
building vanilla dengan miliknya sendiri (target class `ChunkBuilder` vanilla
sudah tidak dipakai). Untuk kasus itu, integrasi throttling harus lewat API
VulkanMod langsung (belum tersedia versi mixin publiknya di scaffold ini).
Dengan Sodium, situasinya mirip — Sodium juga override chunk builder-nya
sendiri, jadi mixin `ChunkBuilder` vanilla mungkin perlu di-retarget ke
kelas Sodium (`SodiumChunkBuilder` / mesh build task classes) tergantung
versi Sodium yang kamu pakai untuk 1.21.11.

**Realistis:** cara paling stabil untuk berinteraksi dengan Sodium/VulkanMod
adalah lewat API resmi mereka (Sodium punya extension API, VulkanMod belum
tentu untuk versi ini) — bukan mixin langsung ke kelas mereka, karena nama
kelas internal berubah tiap update dan gampang crash/incompatible.

## Cara build

1. Butuh JDK 21 dan environment dengan akses internet (untuk resolve
   Fabric Loom, Yarn mappings, Fabric API — sandbox saya tidak punya akses
   internet jadi saya tidak bisa compile/test ini di sini).
2. Cek versi mapping terbaru yang benar-benar tersedia untuk 1.21.11 di
   https://fabricmc.net/develop dan update `gradle.properties` bila beda.
3. Jalankan:
   ```
   ./gradlew genSources
   ```
   lalu buka hasil decompile untuk verifikasi nama method persis
   (`upload*`, `tick`, `shouldRender`, dll — semua sudah saya tandai
   `require = 0` supaya build tidak langsung gagal keras kalau method
   belum cocok, tapi itu artinya mixin itu **silently tidak aktif**
   sampai kamu perbaiki target-nya).
4. Build:
   ```
   ./gradlew build
   ```
   Output jar ada di `build/libs/`.
5. Kalau kamu develop lewat Termux/Codespaces seperti sebelumnya, jalankan
   langkah yang sama di sana — Fabric Loom butuh Gradle daemon yang agak
   berat, jadi Codespaces lebih realistis daripada langsung di HP.

## Kenapa ini "scaffold" bukan mod jadi

Saya tidak punya akses ke Minecraft jar + Yarn mappings 1.21.11 di sandbox
ini untuk compile-test. Semua target mixin (`@At`, nama method) saya isi
berdasarkan pola umum Yarn mapping 1.20.x–1.21.x, tapi **wajib kamu
verifikasi** lewat `genSources` sebelum build final, terutama:
- `ChunkBuilder#upload*` — nama method upload section bisa beda
- `ClientChunkManager#tick` — cek apakah ini method yang benar untuk hook rebuild
- `EntityRenderDispatcher#shouldRender` — signature parameter (Frustum type) perlu disesuaikan
