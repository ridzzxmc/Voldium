# Voldium 2.0 — refactor notes

## 1. Analisis source lama (v1.0.0)

**Entrypoint**: `VoldiumMod` — `ClientModInitializer` saja (tidak ada common
`ModInitializer`). Cocok karena semua fitur (culling, upload throttling) murni
client-side; world-gen tetap jalan lewat integrated server thread di
singleplayer, tapi mixin-nya tetap "client mod" karena hanya aktif saat client
environment jalan.

**Chunk loading & worldgen**: v1.0.0 sama sekali tidak menyentuh worldgen. Satu-
satunya mixin terkait chunk (`MixinClientChunkManager`) hanya menghitung tick
dan punya method `co$shouldRebuildNow` yang **tidak pernah dipanggil** dari mana
pun — pure dead code, cuma kerangka untuk spreading rebuild.

**Rendering pipeline**: tiga mixin — `MixinChunkBuilder` (queue upload, capped
per frame), `MixinWorldRenderer` (drain queue + shrink frustum box), dan
`MixinEntityRenderDispatcher`. Titik kritis: `MixinEntityRenderDispatcher`
selalu `cir.setReturnValue(true)` — **culling entity-nya no-op**, jadi fitur
utama v1.0.0 sebenarnya belum mengurangi apa pun di path itu.

**Threading**: tidak ada. Tidak ada executor/thread pool di codebase lama sama
sekali; semua kerja (termasuk yang niatnya "queue/drain") jalan di render
thread.

### Bottleneck yang teridentifikasi
1. Tidak ada paralelisasi noise/surface sampling saat worldgen → chunk gen
   tetap single-threaded penuh.
2. Tidak ada caching heightmap/biome antar query → kemungkinan recompute
   berulang di render/culling path.
3. Culling entity adalah no-op (`return true` selalu) → tidak ada pengurangan
   draw call entity sama sekali.
4. Tidak ada occlusion culling — hanya frustum margin shrink, dan itu pun
   tidak divalidasi terhadap mapping asli (`method_1002` dsb adalah tebakan).
5. Tidak ada object pooling — v1.0.0 hanya `ArrayDeque<Runnable>` per instance
   `ChunkBuilder`, tidak ada reuse buffer di jalur hot lainnya.

## 2. Arsitektur baru

```
VoldiumMod (entrypoint)
 └─ VoldiumServices (record: dependency bundle)
     ├─ ChunkOptimizer      -> core/ChunkOptimizer, core/ChunkDataCache, util/ObjectPool
     ├─ AsyncWorldGenEngine -> core/AsyncWorldGenEngine (ForkJoinPool)
     ├─ CullingManager      -> culling/CullingManager, util/SectionVisibilityMask
     └─ VisibilityEngine    -> culling/VisibilityEngine, culling/VisibilitySnapshot
 └─ VoldiumClientEvents (Fabric API WorldRenderEvents/HudRenderCallback glue)
 └─ DebugOverlay
 └─ mixin/* (hook points into vanilla; call into the services above)
```

Setiap manager stateless-terhadap-satu-sama-lain di construction time; semua
wiring eksplisit di `VoldiumMod#onInitializeClient`, gampang ditest/diganti.

## 3. ⚠️ Mapping caveat (WAJIB dibaca sebelum build)

Source jar lama sudah pakai nama kelas **intermediary** (`class_846`,
`class_761`, dst) tanpa remap penuh ke Yarn named mappings — pola yang sama
saya pertahankan di refactor ini, plus beberapa target mixin baru (terutama
`MixinNoiseChunkGenerator`) sengaja saya tulis pakai `targets = "fully.qualified.Name"`
placeholder yang **belum tentu match** kelas asli di 1.21.11. Sebelum build:

1. Jalankan `./gradlew genSources` di Loom 1.14+ dev env untuk dapat named
   mappings 1.21.11 yang benar.
2. Cross-check tiap `@Mixin` target & `@Inject method=` di:
   - `MixinChunkBuilder` (class_846 -> ChunkBuilder, method upload*)
   - `MixinWorldRenderer` (class_761 -> WorldRenderer, method render)
   - `MixinClientChunkManager` (class_631 -> ClientChunkManager, method tick)
   - `MixinEntityRenderDispatcher` (shouldRender signature)
   - `MixinNoiseChunkGenerator` (**ditulis ulang total** — cari nama kelas
     generator noise asli di 1.21.11, method populateNoise/buildSurface, dan
     isi `ColumnTask` lambda dengan panggilan ke sampler asli generator itu)
3. `pin` `yarn_mappings` di `gradle.properties` ke build resmi 1.21.11 (nilai
   di file ini placeholder, cek `fabricmc.net/develop`).

Setiap file mixin baru saya kasih komentar `NOTE:` di titik yang butuh
verifikasi manual — jangan hapus sebelum dicek.

## 4. Fitur baru per STEP request kamu

- **Terrain gen**: `AsyncWorldGenEngine` (ForkJoinPool, ukuran dari
  `asyncThreads` config) + kontrak determinisme tertulis di javadoc class-nya
  (thread-local sampler per kolom, no shared RNG, join sebelum lanjut fase).
  `MixinNoiseChunkGenerator` adalah titik hook-nya — sengaja scaffold, bukan
  "auto-working", karena logic noise asli vanilla harus di-copy manual sesuai
  mapping kamu.
- **Chunk lifecycle**: `ChunkOptimizer` + `ChunkDataCache` (bounded LRU,
  read/write lock) untuk heightmap/biome; `ObjectPool<BlockPos.Mutable>` dan
  pool `long[]` scratch buffer untuk kurangi GC churn.
- **Culling lanjutan**: `CullingManager` — frustum margin & entity cull
  distance sekarang di-resolve lewat preset `cullingAggressiveness`
  (LOW/MEDIUM/HIGH), plus occlusion sederhana per-section ("buried section"
  check dari 6 neighbor) yang disimpan di `SectionVisibilityMask` (bitmask
  4096-bit, `long[64]`).
- **Async Visibility Engine (fitur utama)**: `VisibilityEngine` jalan di
  thread terpisah (`Voldium-VisibilityEngine`), lakukan ray-fan traversal
  (DDA-style march tiap 4 block) dari kamera untuk hasilkan potentially-
  visible-set (chunk section + entity id), publish via `AtomicReference`
  double buffering (`VisibilitySnapshot` immutable), dengan hysteresis
  (`visibilityHysteresisFrames`) supaya tidak flicker/pop-in.
- **Entity & block hiding**: kombinasi distance + dot-product arah kamera
  (`CullingManager.isEntityVisible`) + hasil visibility snapshot
  (`MixinEntityRenderDispatcher`), selalu fail-open (kalau ragu, render).

## 5. Config baru (`voldium.json`)

```json
{
  "cullingAggressiveness": "MEDIUM",
  "asyncThreads": -1,
  "enableAsyncVisibility": true,
  "visibilityHysteresisFrames": 2,
  "debugOverlay": false
}
```
`asyncThreads = -1` berarti auto (`availableProcessors() - 2`, clamp 1-6).

## 6. Yang TIDAK diubah (constraint)

- Tidak ada perubahan gameplay vanilla — semua hook bersifat render/perf-only
  atau (untuk worldgen) secara eksplisit dikontrak deterministic-safe.
- Semua `@Inject` pakai `require = 0` (kecuali defaultRequire di mixins.json
  yang perlu kamu sesuaikan setelah verifikasi mapping) supaya mod lain yang
  juga mixin ke kelas yang sama tidak langsung crash-loop kalau target sedikit
  berubah — tapi ini juga berarti **cek log startup** untuk mixin yang
  silent-fail karena target tidak ketemu.

## 7. Yang belum diisi (perlu kerjaan kamu)

- `MixinNoiseChunkGenerator`: body `ColumnTask` lambda kosong (TODO) — ini
  bagian yang paling version/mapping-sensitive, sengaja tidak saya tebak.
- `co$drainQueueBeforeRender`: butuh field handle ke `ChunkBuilder` instance
  aktif dari `WorldRenderer`, sama seperti v1.0.0 (belum diwire).
- Command `/voldium debug` untuk toggle overlay runtime belum ada (saat ini
  overlay hanya baca dari config saat startup) — gampang ditambah lewat
  Fabric API `ClientCommandRegistrationCallback` kalau perlu.
