# Voldium

Mod Fabric client-side buat MC 1.21.11 yang otomatis nurunin/naikin render
distance, simulation distance, particle, dan entity distance scaling
berdasarkan FPS real-time — biar FPS tetep stabil di device lo tanpa lo
oprek settings manual tiap 5 menit.

## Kenapa ini kompatibel sama Sodium & VulkanMod

Mod ini **sama sekali nggak nyentuh kode rendering** (nggak ada mixin ke
chunk builder, shader, atau GPU pipeline). Dia cuma baca `getCurrentFps()`
dan nulis ke `GameOptions` vanilla (render distance dkk) lewat Fabric API
tick event. Karena itu dia jalan sama aja mau lo pake:
- Sodium doang
- VulkanMod doang
- Sodium + VulkanMod bareng (kalo ada versi yang saling kompatibel)
- Vanilla renderer

Efeknya bukan "boost FPS ajaib" kayak ngeganti renderer — ini lebih ke
**stabilizer**: nyegah FPS drop parah pas banyak entity/chunk load dengan
nurunin beban secara otomatis, terus naikin lagi pas udah longgar.

## Build (WAJIB, karena aku nggak bisa compile-in di sini)

Environment aku nggak ada akses internet buat download Minecraft/Fabric
lewat Gradle, jadi ini cuma source code — build sendiri pake salah satu:

### Opsi A — GitHub Codespaces
1. Push folder ini ke repo GitHub baru.
2. Buka di Codespaces.
3. `./gradlew build`
4. Hasil `.jar` ada di `build/libs/voldium-1.0.0.jar`

### Opsi B — Termux (langsung di HP)
```bash
pkg install openjdk-21 git
git clone <repo-lo>
cd voldium
./gradlew build
```
Build Gradle pertama kali bakal download banyak (Minecraft jar, Yarn
mappings, Fabric API) — pastiin koneksi lancar & storage cukup (~1-2GB).

## Install di Zalith Launcher
1. Pastiin sudah pasang **Fabric Loader 0.18.1+** untuk 1.21.11 di profil Zalith.
2. Copy `voldium-1.0.0.jar` dan `fabric-api` jar ke folder `mods/` versi itu.
3. (Opsional) pasang Sodium dan/atau VulkanMod di folder `mods/` yang sama.
4. Launch.

## Kalau build gagal karena mapping

1.21.11 baru aja transisi dari obfuscated ke unobfuscated mapping, jadi
kalau ada error "cannot resolve method/field" pas compile:
1. Jalanin `./gradlew genSources`
2. Buka `GameOptions.java` hasil decompile di
   `build/loom-cache/.../net/minecraft/client/option/GameOptions.java`
3. Cocokin nama field `viewDistance` / `simulationDistance` /
   `particles` / `entityDistanceScaling` — kalau namanya beda dikit,
   tinggal rename di `FpsStabilizer.java`.

## Config

`config/voldium.json` (auto-generate on first run):
```json
{
  "enabled": true,
  "targetFps": 40,
  "minRenderDistance": 3,
  "maxRenderDistance": 8,
  "minSimulationDistance": 3,
  "maxSimulationDistance": 8
}
```
Naikin `targetFps` kalau device lo lebih kenceng dari Mali-G57/Adreno 505.
