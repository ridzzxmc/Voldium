# Voldium (scaffold) — Minecraft 1.21.11 Fabric

Mod add-on untuk mengurangi stutter dan meningkatkan FPS lewat:
- Throttling upload chunk mesh per frame (`MixinChunkBuilder`)
- Menyebar rebuild chunk ke beberapa tick, bukan sekaligus (`MixinClientChunkManager`)
- Frustum culling lebih ketat dengan margin lebih kecil (`MixinWorldRenderer`)
- Distance-based culling untuk entity di luar jarak tertentu (`MixinEntityRenderDispatcher`)

## ⚠️ PENTING: Sodium vs VulkanMod

**Sodium dan VulkanMod tidak bisa jalan bersamaan.** Keduanya sama-sama
menggantikan seluruh chunk/terrain rendering engine vanilla. Ini persis
sumber crash yang kamu alami sebelumnya (VulkanMod vs Mali-G57/Adreno 505).
Pilih salah satu:

- **Sodium** → aktifkan `sodiumCompat: true`, `vulkanModCompat: false` di config
- **VulkanMod** → sebaliknya

Mod ini otomatis mendeteksi mod mana yang ter-load (`VoldiumMod.java`)
dan akan mencatat error di log kalau kamu memasang keduanya sekaligus.

Catatan lain: kalau kamu pakai VulkanMod, mixin `MixinChunkBuilder` kemungkinan
besar **tidak berpengaruh**, karena VulkanMod mengganti total pipeline chunk
building vanilla dengan miliknya sendiri (target class `ChunkBuilder` vanilla
sudah tidak dipakai). Untuk kasus itu, integrasi throttling harus lewat API
VulkanMod langsung (belum tersedia versi mixin publiknya di scaffold ini).
Dengan Sodium, situasinya mirip — Sodium juga override chunk builder-nya
sendiri, jadi mixin `ChunkBuilder` vanilla mungkin perlu di-retarget ke
kelas Sodium (`SodiumChunkBuilder` / mesh build task classes) tergantung
versi Sodium yang kamu pakai untuk 1.21.11.

**Realistis:** cara paling stabil untuk berinteraksi dengan Sodium/VulkanMod
adalah lewat API resmi mereka (Sodium punya extension API, VulkanMod belum
tentu untuk versi ini) — bukan mixin langsung ke kelas mereka, karena nama
kelas internal berubah tiap update dan gampang crash/incompatible.

## Perbaikan build yang gagal (Gradle 8.0.2 / mismatch versi)

Versi awal scaffold ini salah menentukan versi Loom, Loader, dan Fabric API
untuk 1.21.11 — itulah penyebab `BUILD FAILED` yang kamu alami. Sudah
diperbaiki dengan versi yang benar-benar dicek ke maven.fabricmc.net dan
Modrinth (per Juli 2026):

- Fabric Loom: **1.14** (versi resmi yang direkomendasikan Fabric untuk
  1.21.11, ini juga versi obfuscated terakhir sebelum Minecraft pindah ke
  mapping non-obfuscated)
- Yarn mappings: **1.21.11+build.4**
- Fabric Loader: **0.19.3**
- Fabric API: **0.141.4+1.21.11**
- Loom 1.14 butuh minimum **Gradle 9.2** (bukan 8.x seperti yang dipakai
  environment kamu sebelumnya — itu akar masalah BUILD FAILED-nya)

### Langkah build di Codespaces

1. Hapus dulu proses SDKMAN yang mungkin masih jalan (Ctrl+C di terminal).
2. Generate Gradle Wrapper dengan versi yang benar (pakai `gradle` sistem
   yang sudah ada):
   ```
   cd /workspaces/Voldium
   gradle wrapper --gradle-version 9.3 --distribution-type bin
   ```
3. Build pakai wrapper (bukan `gradle` sistem lagi setelah ini):
   ```
   ./gradlew build --no-daemon --stacktrace
   ```
4. Kalau masih gagal di step resolve mappings/loader, jalankan
   `./gradlew build --refresh-dependencies` untuk memaksa re-download.

Setelah wrapper ke-generate sekali dengan versi yang benar, tidak perlu
install/ganti Gradle manual lagi — `./gradlew` akan otomatis pakai Gradle
9.3 setiap kali.



## Cara build (ringkas)

1. Butuh JDK 21.
2. Ikuti langkah "Perbaikan build" di atas untuk generate wrapper dulu,
   lalu jalankan `./gradlew genSources` untuk verifikasi nama method mixin
   sebelum full build (`upload*`, `tick`, `shouldRender` ditandai
   `require = 0`, artinya kalau namanya salah, mixin itu diam-diam
   tidak aktif, bukan bikin build gagal — jadi wajib dicek manual).
3. Build: `./gradlew build`. Output jar ada di `build/libs/`.

## Kenapa ini "scaffold" bukan mod jadi

Saya tidak punya akses ke Minecraft jar + Yarn mappings 1.21.11 di sandbox
ini untuk compile-test. Semua target mixin (`@At`, nama method) saya isi
berdasarkan pola umum Yarn mapping 1.20.x–1.21.x, tapi **wajib kamu
verifikasi** lewat `genSources` sebelum build final, terutama:
- `ChunkBuilder#upload*` — nama method upload section bisa beda
- `ClientChunkManager#tick` — cek apakah ini method yang benar untuk hook rebuild
- `EntityRenderDispatcher#shouldRender` — signature parameter (Frustum type) perlu disesuaikan
