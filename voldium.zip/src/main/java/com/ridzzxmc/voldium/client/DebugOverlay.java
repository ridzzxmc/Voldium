package com.ridzzxmc.voldium.client;

import com.ridzzxmc.voldium.VoldiumMod;
import com.ridzzxmc.voldium.culling.CullingManager;
import com.ridzzxmc.voldium.culling.VisibilityEngine;
import net.minecraft.class_310; // MinecraftClient
import net.minecraft.class_332; // DrawContext

/**
 * Small always-on-top text overlay, toggled via config.debugOverlay
 * (exposed as /voldium debug in a full build — wire a command if desired).
 * Deliberately reads straight from the live manager instances instead of
 * a separate stats-copy step: this runs once per frame on the render
 * thread already, so there's no extra synchronization to do.
 */
public final class DebugOverlay {

    private DebugOverlay() {}

    public static void render(class_332 context, CullingManager cullingManager, VisibilityEngine visibilityEngine) {
        class_310 client = class_310.method_1551();
        if (client.field_1687 == null) return;

        int x = 6, y = 6, lineHeight = 10, color = 0xFFFFFF;
        int fps = client.method_31321(); // getCurrentFps-equivalent

        var snapshot = visibilityEngine.getSnapshot();

        String[] lines = new String[] {
                "\u00a7bVoldium\u00a7r  fps=" + fps,
                "sections visible=" + snapshot.sectionCount() + " entities visible=" + snapshot.entityCount(),
                "culled sections=" + cullingManager.getCulledSectionsLastFrame()
                        + " culled entities=" + cullingManager.getCulledEntitiesLastFrame(),
                "frustum tests=" + cullingManager.getFrustumTestsLastFrame(),
                "aggressiveness=" + VoldiumMod.CONFIG.cullingAggressiveness
                        + " asyncThreads=" + VoldiumMod.CONFIG.resolveAsyncThreads(),
                VoldiumMod.SERVICES.worldGenEngine() != null
                        ? String.format("last chunk gen=%.2fms total=%d",
                                VoldiumMod.SERVICES.worldGenEngine().getLastChunkGenMillis(),
                                VoldiumMod.SERVICES.worldGenEngine().getTotalChunksGenerated())
                        : "worldgen engine: n/a",
        };

        for (int i = 0; i < lines.length; i++) {
            context.method_51433(client.field_1772, lines[i], x, y + i * lineHeight, color, true);
        }
    }
}
