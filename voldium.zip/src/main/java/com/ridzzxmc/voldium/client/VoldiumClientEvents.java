package com.ridzzxmc.voldium.client;

import com.ridzzxmc.voldium.VoldiumMod;
import com.ridzzxmc.voldium.culling.CullingManager;
import com.ridzzxmc.voldium.culling.VisibilityEngine;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_310; // MinecraftClient

import java.util.List;

/**
 * Wires Voldium's services into Fabric API's public event hooks. Kept
 * separate from VoldiumMod so the entrypoint stays a thin bootstrap and
 * this class stays a pure "event glue" module you can unit-reason-about
 * on its own.
 */
public final class VoldiumClientEvents {

    private static double lastYaw = Double.NaN;
    private static double lastPitch = Double.NaN;
    private static int ticksSinceForcedRecompute = 0;

    private VoldiumClientEvents() {}

    public static void register(CullingManager cullingManager, VisibilityEngine visibilityEngine) {
        WorldRenderEvents.START.register(context -> cullingManager.resetFrameCounters());

        // Trigger an async visibility recompute when the camera moved/turned
        // enough to matter, or as a periodic safety net for moving entities.
        WorldRenderEvents.BEFORE_ENTITIES.register(context -> {
            class_310 client = class_310.method_1551();
            if (client.field_1687 == null || client.field_1724 == null) return;

            var camera = context.camera();
            double yaw = camera.method_19330();
            double pitch = camera.method_19329();

            boolean moved = Double.isNaN(lastYaw)
                    || Math.abs(yaw - lastYaw) > VoldiumMod.CONFIG.staticFrameAngleThreshold
                    || Math.abs(pitch - lastPitch) > VoldiumMod.CONFIG.staticFrameAngleThreshold;

            ticksSinceForcedRecompute++;
            boolean forced = ticksSinceForcedRecompute > 10; // safety net: at least every ~10 frames

            if (moved || forced) {
                lastYaw = yaw;
                lastPitch = pitch;
                ticksSinceForcedRecompute = 0;

                int renderDistance = client.field_1690 != null ? client.field_1690.method_42474().method_41753() : 8;
                List<net.minecraft.class_1297> candidates = client.field_1687.method_18112();
                visibilityEngine.requestRecompute(client.field_1687, camera, renderDistance, candidates);
            }
        });

        if (VoldiumMod.CONFIG.debugOverlay) {
            HudRenderCallback.EVENT.register((drawContext, tickDelta) ->
                    DebugOverlay.render(drawContext, cullingManager, visibilityEngine));
        }
    }
}
