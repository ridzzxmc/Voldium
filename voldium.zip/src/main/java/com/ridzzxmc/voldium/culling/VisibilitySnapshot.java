package com.ridzzxmc.voldium.culling;

import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;

import java.util.Collections;
import java.util.Set;

/**
 * An immutable "potentially visible set" computed off the render thread by
 * VisibilityEngine. The render thread only ever reads a fully-built
 * snapshot via an AtomicReference swap — never a half-built one — so this
 * class must stay effectively immutable after construction.
 *
 * Uses fastutil's LongOpenHashSet (already a transitive Fabric API /
 * Minecraft dependency) instead of boxed Long HashSet to avoid boxing
 * churn on a per-frame hot path.
 */
public final class VisibilitySnapshot {

    public static final VisibilitySnapshot EMPTY =
            new VisibilitySnapshot(LongSet.of(), Collections.emptySet(), 0L, 0);

    /** Packed ChunkSectionPos.asLong() values considered potentially visible. */
    private final LongSet visibleSections;

    /** Entity network/world IDs considered visible this snapshot. */
    private final Set<Integer> visibleEntityIds;

    private final long computedAtNanos;
    private final int frameStamp;

    public VisibilitySnapshot(LongSet visibleSections, Set<Integer> visibleEntityIds,
                               long computedAtNanos, int frameStamp) {
        // Defensive copy into an unmodifiable-in-spirit set; VisibilityEngine
        // never touches these instances again after handing them off.
        this.visibleSections = new LongOpenHashSet(visibleSections);
        this.visibleEntityIds = Set.copyOf(visibleEntityIds);
        this.computedAtNanos = computedAtNanos;
        this.frameStamp = frameStamp;
    }

    public boolean isSectionVisible(long packedSectionPos) {
        return visibleSections.isEmpty() ? true : visibleSections.contains(packedSectionPos);
    }

    public boolean isEntityVisible(int entityId) {
        return visibleEntityIds.isEmpty() ? true : visibleEntityIds.contains(entityId);
    }

    public int sectionCount() { return visibleSections.size(); }
    public int entityCount() { return visibleEntityIds.size(); }
    public long computedAtNanos() { return computedAtNanos; }
    public int frameStamp() { return frameStamp; }
}
