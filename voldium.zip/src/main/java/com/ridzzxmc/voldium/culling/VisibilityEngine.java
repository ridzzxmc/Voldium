package com.ridzzxmc.voldium.culling;

import com.ridzzxmc.voldium.VoldiumMod;
import com.ridzzxmc.voldium.config.VoldiumConfig;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import it.unimi.dsi.fastutil.longs.LongSet;
import net.minecraft.class_4184; // Camera
import net.minecraft.class_2338; // BlockPos
import net.minecraft.class_1937; // World
import net.minecraft.class_1297; // Entity

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

/**
 * FITUR UTAMA: async visibility engine.
 *
 * Runs a coarse ray-traversal potentially-visible-set (PVS) computation on
 * a dedicated background thread, decoupled from the render thread via a
 * double-buffered snapshot (AtomicReference swap — the render thread only
 * ever dereferences a fully-built, immutable VisibilitySnapshot, never a
 * half-written one, and there is no locking on the render-thread read
 * path).
 *
 * Algorithm (per recompute pass):
 *  1. Snapshot camera position + look direction (read-only, main-thread
 *     values captured once per pass, no shared mutable state).
 *  2. For a fan of rays across the camera's FOV (coarse angular step, NOT
 *     per-pixel — this is a visibility approximation, not a renderer), walk
 *     a 3D-DDA grid traversal through chunk sections out to render distance.
 *     A ray stops advancing through a section if CullingManager reports
 *     that section as fully occluded; every section it *does* pass through
 *     gets added to the visible set.
 *  3. Entities are resolved visible if: their containing section is in the
 *     visible set, AND CullingManager.isEntityVisible(...) passes
 *     (distance + direction dot-product test).
 *  4. Hysteresis: sections/entities visible in the PREVIOUS snapshot stay
 *     visible in this one for `visibilityHysteresisFrames` extra passes
 *     even if this pass didn't re-confirm them, which absorbs the one
 *     frame of latency between "camera moved" and "new snapshot published"
 *     and avoids visible pop-in/flicker on fast turns.
 *
 * Recompute is triggered by VoldiumClientEvents only when the camera moved/
 * rotated past config.staticFrameAngleThreshold, or every N ticks as a
 * safety net (entities move even if the camera doesn't).
 */
public final class VisibilityEngine {

    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Voldium-VisibilityEngine");
        t.setDaemon(true);
        return t;
    });

    private final CullingManager cullingManager;
    private final AtomicReference<VisibilitySnapshot> currentSnapshot =
            new AtomicReference<>(VisibilitySnapshot.EMPTY);

    private final AtomicBoolean computeInFlight = new AtomicBoolean(false);
    private final AtomicInteger frameStampCounter = new AtomicInteger();

    // Hysteresis carry-over from the previous published snapshot.
    private volatile LongSet stickySections = LongSet.of();
    private volatile Set<Integer> stickyEntities = Set.of();
    private volatile int stickyFramesRemaining = 0;

    public VisibilityEngine(CullingManager cullingManager) {
        this.cullingManager = cullingManager;
    }

    /** Immutable, render-thread-captured snapshot of one entity's position, handed off to the worker thread. */
    private record EntitySample(int id, double x, double y, double z) {}

    public VisibilitySnapshot getSnapshot() {
        return currentSnapshot.get();
    }

    /**
     * Requests an async recompute. No-op if a compute is already in
     * flight (we don't queue up stale requests — by the time an old one
     * would run, the camera has moved again anyway).
     */
    public void requestRecompute(class_1937 world, class_4184 camera, int renderDistanceChunks, List<class_1297> candidateEntities) {
        if (!VoldiumMod.CONFIG.enableAsyncVisibility) return;
        if (!computeInFlight.compareAndSet(false, true)) return;

        // Capture immutable snapshot inputs on the calling (render/client)
        // thread before handing off, so the worker never touches live
        // mutable game state concurrently with the render thread.
        var pos = camera.method_19326();
        var look = camera.method_19334();
        double camX = pos.field_1352, camY = pos.field_1351, camZ = pos.field_1350;
        double dirX = look.field_1352, dirY = look.field_1351, dirZ = look.field_1350;

        List<EntitySample> samples = candidateEntities.stream()
                .map(e -> new EntitySample(e.method_5628(), e.method_23317(), e.method_23318(), e.method_23321()))
                .toList();

        executor.submit(() -> {
            try {
                computePass(camX, camY, camZ, dirX, dirY, dirZ, renderDistanceChunks, samples);
            } catch (Throwable t) {
                VoldiumMod.LOGGER.error("[Voldium] VisibilityEngine pass failed, keeping previous snapshot", t);
            } finally {
                computeInFlight.set(false);
            }
        });
    }

    private void computePass(double camX, double camY, double camZ,
                              double dirX, double dirY, double dirZ,
                              int renderDistanceChunks, List<EntitySample> entitySamples) {
        LongSet visibleSections = new LongOpenHashSet();
        Set<Integer> visibleEntities = new HashSet<>();

        // Coarse angular fan: yaw/pitch step chosen so total rays stay
        // cheap (~a few hundred) regardless of FOV/render distance.
        final int yawSteps = 48;
        final int pitchSteps = 12;
        final double halfFovYaw = Math.toRadians(70);
        final double halfFovPitch = Math.toRadians(50);
        final double baseYaw = Math.atan2(dirZ, dirX);
        final double basePitch = Math.asin(clamp(dirY, -1, 1));

        for (int yi = 0; yi <= yawSteps; yi++) {
            double yaw = baseYaw - halfFovYaw + (2 * halfFovYaw) * yi / yawSteps;
            for (int pi = 0; pi <= pitchSteps; pi++) {
                double pitch = basePitch - halfFovPitch + (2 * halfFovPitch) * pi / pitchSteps;
                double rx = Math.cos(pitch) * Math.cos(yaw);
                double ry = Math.sin(pitch);
                double rz = Math.cos(pitch) * Math.sin(yaw);
                traverseRay(camX, camY, camZ, rx, ry, rz, renderDistanceChunks * 16, visibleSections);
            }
        }

        // Entity visibility follows section visibility; falls back to
        // "visible" if we have no section data at all (fail-open).
        for (EntitySample e : entitySamples) {
            long sectionKey = packSection(
                    ((int) Math.floor(e.x())) >> 4,
                    ((int) Math.floor(e.y())) >> 4,
                    ((int) Math.floor(e.z())) >> 4);
            if (visibleSections.isEmpty() || visibleSections.contains(sectionKey)) {
                visibleEntities.add(e.id());
            }
        }

        publishWithHysteresis(visibleSections, visibleEntities);
    }

    /** Simple 3D-DDA style march in fixed block steps (cheap, not exact but fine for a coarse PVS). */
    private void traverseRay(double x, double y, double z, double dx, double dy, double dz,
                              double maxDist, LongSet outVisible) {
        final double step = 4.0; // blocks per march step; coarse on purpose
        double traveled = 0;
        while (traveled < maxDist) {
            int sx = ((int) Math.floor(x)) >> 4;
            int sy = ((int) Math.floor(y)) >> 4;
            int sz = ((int) Math.floor(z)) >> 4;
            long key = packSection(sx, sy, sz);

            if (cullingManager.isSectionOccluded(key)) {
                return; // ray absorbed by an occluded section, stop marching
            }
            outVisible.add(key);

            x += dx * step;
            y += dy * step;
            z += dz * step;
            traveled += step;
        }
    }

    private void publishWithHysteresis(LongSet freshSections, Set<Integer> freshEntities) {
        VoldiumConfig cfg = VoldiumMod.CONFIG;
        LongSet merged = new LongOpenHashSet(freshSections);
        Set<Integer> mergedEntities = new HashSet<>(freshEntities);

        if (stickyFramesRemaining > 0) {
            merged.addAll(stickySections);
            mergedEntities.addAll(stickyEntities);
        }

        stickySections = freshSections;
        stickyEntities = freshEntities;
        stickyFramesRemaining = Math.max(0, cfg.visibilityHysteresisFrames);

        VisibilitySnapshot snapshot = new VisibilitySnapshot(
                merged, mergedEntities, System.nanoTime(), frameStampCounter.incrementAndGet());
        currentSnapshot.set(snapshot);
    }

    private static long packSection(int x, int y, int z) {
        // Same bit layout family as vanilla ChunkSectionPos.asLong (19/19/26 bit-ish split
        // isn't critical here since this key is internal-only); just needs to be a stable,
        // collision-free packing for the range of the world.
        return (((long) x & 0x3FFFFF) << 42) | (((long) y & 0xFFFFF) << 22) | ((long) z & 0x3FFFFF);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public void shutdown() {
        executor.shutdownNow();
    }
}
