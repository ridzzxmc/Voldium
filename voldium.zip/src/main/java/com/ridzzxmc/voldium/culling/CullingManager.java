package com.ridzzxmc.voldium.culling;

import com.ridzzxmc.voldium.VoldiumMod;
import com.ridzzxmc.voldium.config.VoldiumConfig;
import com.ridzzxmc.voldium.util.SectionVisibilityMask;
import net.minecraft.class_4184; // Camera
import net.minecraft.class_4604; // Frustum
import net.minecraft.class_2338; // BlockPos

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Coordinates frustum culling (improved margins from config) and a coarse,
 * chunk-section-granularity occlusion pass, exposing a per-section
 * SectionVisibilityMask consumed by VisibilityEngine when it builds a
 * VisibilitySnapshot, and consulted directly by MixinWorldRenderer /
 * MixinEntityRenderDispatcher for the fast-path per-object checks.
 *
 * Occlusion strategy (deliberately simple & cheap, NOT full software
 * rasterization): a chunk section is flagged "fully occluded" only when
 * ALL SIX face-neighbor sections are fully opaque (i.e. this section is
 * buried, can only happen underground/inside solid mass) AND it is not
 * the section directly containing the camera. This catches the common,
 * expensive case — deep cave/underground sections behind solid rock —
 * cheaply, without doing per-block raycasts against the whole world.
 * The AsyncVisibilityEngine layers finer-grained ray-based checks on top
 * for the entity/section list actually near the frustum edge.
 */
public final class CullingManager {

    private final ConcurrentHashMap<Long, SectionVisibilityMask> sectionMasks = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<Long, Boolean> fullyOccludedSections = new ConcurrentHashMap<>();

    private final AtomicLong culledSectionsLastFrame = new AtomicLong();
    private final AtomicLong culledEntitiesLastFrame = new AtomicLong();
    private final AtomicInteger frustumTestsLastFrame = new AtomicInteger();

    public float resolveFrustumMargin() {
        VoldiumConfig cfg = VoldiumMod.CONFIG;
        return switch (cfg.cullingAggressiveness) {
            case LOW -> Math.max(0.5f, cfg.frustumMarginBlocks * 0.5f);
            case MEDIUM -> cfg.frustumMarginBlocks;
            case HIGH -> cfg.frustumMarginBlocks * 1.75f;
        };
    }

    public int resolveEntityCullDistance() {
        VoldiumConfig cfg = VoldiumMod.CONFIG;
        return switch (cfg.cullingAggressiveness) {
            case LOW -> (int) (cfg.entityCullDistance * 1.3f);
            case MEDIUM -> cfg.entityCullDistance;
            case HIGH -> (int) (cfg.entityCullDistance * 0.75f);
        };
    }

    /** Frustum test against a chunk section's AABB, with the configured inward margin applied. */
    public boolean isSectionInFrustum(class_4604 frustum, double minX, double minY, double minZ,
                                       double maxX, double maxY, double maxZ) {
        frustumTestsLastFrame.incrementAndGet();
        float m = resolveFrustumMargin();
        return frustum.method_23096(minX + m, minY + m, minZ + m, maxX - m, maxY - m, maxZ - m);
    }

    /**
     * Marks/refreshes the occlusion state for a section based on its 6
     * neighbors' "fully solid section" flags. Called from the light/mesh
     * update path (cheap: 6 map lookups), not per-frame.
     */
    public void updateOcclusionState(long sectionPos, boolean[] neighborsFullySolid, boolean containsCamera) {
        boolean occluded = !containsCamera;
        if (occluded) {
            for (boolean solid : neighborsFullySolid) {
                if (!solid) { occluded = false; break; }
            }
        }
        fullyOccludedSections.put(sectionPos, occluded);
    }

    public boolean isSectionOccluded(long sectionPos) {
        return Boolean.TRUE.equals(fullyOccludedSections.get(sectionPos));
    }

    public SectionVisibilityMask getOrCreateMask(long sectionPos) {
        return sectionMasks.computeIfAbsent(sectionPos, k -> {
            SectionVisibilityMask mask = new SectionVisibilityMask();
            mask.setAllVisible(); // fail-open until occlusion data is computed
            return mask;
        });
    }

    public boolean isEntityVisible(class_4184 camera, double entityX, double entityY, double entityZ,
                                    boolean inFrustum) {
        VoldiumConfig cfg = VoldiumMod.CONFIG;
        int cullDist = resolveEntityCullDistance();
        if (cullDist <= 0) return true;

        double dx = entityX - camera.method_19326().field_1352;
        double dy = entityY - camera.method_19326().field_1351;
        double dz = entityZ - camera.method_19326().field_1350;
        double distSq = dx * dx + dy * dy + dz * dz;

        if (distSq > (double) cullDist * cullDist) {
            // Far away AND not in the (already-margin-shrunk) frustum -> cull.
            if (!inFrustum) {
                culledEntitiesLastFrame.incrementAndGet();
                return false;
            }
        }

        // Direction test: dot product between camera look vector and vector
        // to entity, catches "technically in frustum bounding test but
        // directly behind camera at a weird angle" edge cases cheaply.
        if (cfg.entityOcclusionCulling && distSq > 4.0) {
            var look = camera.method_19334();
            double invLen = 1.0 / Math.sqrt(distSq);
            double dot = (dx * invLen) * look.field_1352 + (dy * invLen) * look.field_1351 + (dz * invLen) * look.field_1350;
            if (dot < -0.6) { // well behind the camera
                culledEntitiesLastFrame.incrementAndGet();
                return false;
            }
        }

        return true;
    }

    public void resetFrameCounters() {
        culledSectionsLastFrame.set(0);
        culledEntitiesLastFrame.set(0);
        frustumTestsLastFrame.set(0);
    }

    public void recordCulledSection() { culledSectionsLastFrame.incrementAndGet(); }

    public long getCulledSectionsLastFrame() { return culledSectionsLastFrame.get(); }
    public long getCulledEntitiesLastFrame() { return culledEntitiesLastFrame.get(); }
    public int getFrustumTestsLastFrame() { return frustumTestsLastFrame.get(); }

    public void onChunkUnload(long sectionPosPrefix) {
        sectionMasks.remove(sectionPosPrefix);
        fullyOccludedSections.remove(sectionPosPrefix);
    }
}
