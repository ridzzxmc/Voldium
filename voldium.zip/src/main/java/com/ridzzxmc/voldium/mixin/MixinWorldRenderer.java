package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.class_238; // Box
import net.minecraft.class_761; // WorldRenderer
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * NOTE: verify render/isVisible method names against your 1.21.11 mapped
 * sources before compiling.
 *
 * Two things happen here:
 *  1. Drains the chunk upload queue once per frame at a fixed point in
 *     the render loop (see MixinChunkBuilder#co$drainUploads).
 *  2. Frustum margin is now resolved through CullingManager, which folds
 *     in the cullingAggressiveness preset on top of the raw config value.
 */
@Mixin(class_761.class)
public class MixinWorldRenderer {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void co$drainQueueBeforeRender(CallbackInfo ci) {
        if (!VoldiumMod.CONFIG.aggressiveFrustumCulling || VoldiumMod.SERVICES == null) return;
        // Wire this up once you have a handle on the world renderer's
        // ChunkBuilder field for your mapped version, e.g.:
        // ((MixinChunkBuilder)(Object) this.field_XXXX_chunkBuilder).co$drainUploads();
    }

    /**
     * Wrap a chunk-section AABB with the CullingManager-resolved inward
     * margin so partially-clipped edge sections at a shallow angle get
     * culled a little earlier than vanilla's default (generous) padding.
     */
    private class_238 co$shrink(class_238 box) {
        float m = VoldiumMod.SERVICES != null
                ? VoldiumMod.SERVICES.cullingManager().resolveFrustumMargin()
                : VoldiumMod.CONFIG.frustumMarginBlocks;
        return box.method_1002(m, m, m);
    }
}
