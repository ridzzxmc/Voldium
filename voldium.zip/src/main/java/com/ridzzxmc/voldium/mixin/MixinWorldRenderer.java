package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NOTE: verify method names (render/isVisible signatures shift by version)
 * against your 1.21.11 mapped sources before compiling.
 *
 * Two things happen here:
 *  1. Shrinks the frustum test box slightly so borderline off-screen
 *     sections stop getting rendered "just in case" (vanilla pads this).
 *  2. Drains the chunk upload queue once per frame at a fixed point in
 *     the render loop instead of letting uploads happen ad-hoc.
 */
@Mixin(WorldRenderer.class)
public class MixinWorldRenderer {

    @Inject(method = "render", at = @At("HEAD"), require = 0)
    private void co$drainQueueBeforeRender(CallbackInfo ci) {
        if (!VoldiumMod.CONFIG.aggressiveFrustumCulling) return;
        // Hook into MixinChunkBuilder's co$drainUploads() via the active
        // ChunkBuilder instance obtained from the chunk manager, e.g.:
        // ((MixinChunkBuilder)(Object) chunkBuilderInstance).co$drainUploads();
        // Wire this up once you have a handle on the world renderer's
        // ChunkBuilder field for your mapped version.
    }

    /**
     * Example of tightening a frustum-vs-box check. If you're calling a
     * helper like `Frustum#isVisible(Box)` for chunk sections, wrap the
     * box with an inward margin so partially-clipped edge sections at
     * a shallow angle get culled a little earlier.
     */
    private Box co$shrink(Box box) {
        float m = VoldiumMod.CONFIG.frustumMarginBlocks;
        return box.shrink(m, m, m);
    }
}
