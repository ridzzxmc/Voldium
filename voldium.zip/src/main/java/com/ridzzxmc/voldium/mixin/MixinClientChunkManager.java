package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.class_631; // ClientChunkManager
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Spreads the burst of chunk rebuilds that happens when the player crosses
 * a chunk border (vanilla marks/rebuilds a whole ring of sections at
 * once — the classic "walk forward -> fps drops for a tick" stutter).
 * Newly-dirty sections are tagged with a small delay counter instead of
 * rebuilding them all in the same tick.
 *
 * Also feeds ChunkOptimizer's lifecycle counters so the debug overlay can
 * show chunks-loaded/sec.
 *
 * NOTE: exact method to hook (markDirty / updateLoadDistance / similar)
 * depends on 1.21.11 mappings — confirm the real method name/signature.
 */
@Mixin(class_631.class)
public class MixinClientChunkManager {

    private int co$tickCounter = 0;

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void co$onTick(CallbackInfo ci) {
        co$tickCounter++;
    }

    /**
     * Called from the (hypothetical) markDirty hook. Returns true if this
     * chunk section should rebuild THIS tick, spreading the rebuild load
     * over chunkRebuildSpreadTicks ticks based on a hash of its
     * coordinates so a whole ring doesn't land on the same tick.
     */
    private boolean co$shouldRebuildNow(int chunkX, int chunkZ) {
        int spread = Math.max(1, VoldiumMod.CONFIG.chunkRebuildSpreadTicks);
        int bucket = Math.floorMod((chunkX * 31 + chunkZ), spread);
        return (co$tickCounter % spread) == bucket;
    }

    /** Called from the (hypothetical) chunk-load callback. */
    private void co$onChunkLoaded() {
        if (VoldiumMod.SERVICES != null) {
            VoldiumMod.SERVICES.chunkOptimizer().onChunkLoaded();
        }
    }
}
