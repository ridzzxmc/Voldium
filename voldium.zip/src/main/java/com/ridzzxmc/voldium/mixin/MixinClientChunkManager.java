package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.client.world.ClientChunkManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Spreads the burst of chunk rebuilds that happens when the player crosses
 * a chunk border (vanilla tries to mark/rebuild a whole ring of sections
 * at once, which is the classic "walk forward -> fps drops for a tick"
 * stutter). We tag newly-dirty sections with a small delay counter instead
 * of rebuilding them all in the same tick.
 *
 * NOTE: exact method to hook (markDirty / updateLoadDistance / similar)
 * depends on 1.21.11 mappings -- confirm the real method name/signature.
 */
@Mixin(ClientChunkManager.class)
public class MixinClientChunkManager {

    private int co$tickCounter = 0;

    @Inject(method = "tick", at = @At("HEAD"), require = 0)
    private void co$onTick(CallbackInfo ci) {
        co$tickCounter++;
    }

    /**
     * Called from the (hypothetical) markDirty hook. Returns true if this
     * particular chunk section should rebuild THIS tick, spreading the
     * rebuild load over chunkRebuildSpreadTicks ticks based on a hash of
     * its coordinates so the ring doesn't all land on the same tick.
     */
    private boolean co$shouldRebuildNow(int chunkX, int chunkZ) {
        int spread = Math.max(1, VoldiumMod.CONFIG.chunkRebuildSpreadTicks);
        int bucket = Math.floorMod((chunkX * 31 + chunkZ), spread);
        return (co$tickCounter % spread) == bucket;
    }
}
