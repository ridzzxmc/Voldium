package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.class_2791; // Chunk (chunk being populated)
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NOTE: the real class here is Minecraft's NoiseChunkGenerator (or
 * whatever it's renamed to in your 1.21.11 mappings — check genSources).
 * `class_2791` above is a placeholder for the Chunk parameter type; the
 * @Mixin target class below is left as a fully-qualified guess
 * ("net.minecraft.world.gen.chunk.NoiseChunkGenerator") specifically so
 * Loom's mixin annotation processor will fail the build with a clear
 * "target class not found" error rather than silently no-op'ing — you
 * MUST re-point this at the real class before this mixin does anything.
 *
 * Hook strategy: intercept the surface-building / noise-population phase
 * (commonly called something like `buildSurface` or `populateNoise` on
 * this class) at HEAD, cancel the vanilla single-threaded call, and
 * replace it with AsyncWorldGenEngine#generateChunkColumnsParallel(...)
 * doing the exact same per-column work, just splayed across worker
 * threads and joined before we return control.
 *
 * This is intentionally left as a scaffold rather than a magically
 * "working" override: the actual per-column noise/surface logic lives
 * deep in vanilla's DensityFunction / SurfaceRules evaluation and must be
 * copied (or delegated back into vanilla helper calls) column-by-column
 * inside the ColumnTask lambda below. See AsyncWorldGenEngine's class
 * doc for the determinism rules that lambda must follow.
 */
@Mixin(targets = "net.minecraft.world.gen.chunk.NoiseChunkGenerator", remap = false)
public class MixinNoiseChunkGenerator {

    @Inject(method = "populateNoise", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$parallelPopulateNoise(Object region, Object structureAccessor, class_2791 chunk,
                                           CallbackInfoReturnable<Object> cir) {
        if (VoldiumMod.SERVICES == null || VoldiumMod.SERVICES.worldGenEngine() == null) return;

        // Guard: only take the async path when we're actually off the
        // render thread already (vanilla chunk gen runs on its own
        // executor), so we never contend with the main/render thread for
        // this pool's workers.
        if (isRenderThread()) return;

        VoldiumMod.SERVICES.worldGenEngine().generateChunkColumnsParallel((localX, localZ) -> {
            // TODO: replace with the real per-column noise/surface call,
            // e.g. delegating to this generator's own column sampler:
            //   this.sampleAndBuildColumn(chunk, localX, localZ, ...);
            // Each column MUST only write into chunk data for (localX,
            // localZ) — see AsyncWorldGenEngine's determinism contract.
        });

        // Once the real per-column delegation above is wired in, cancel
        // the vanilla single-threaded call and return the (now populated)
        // chunk/region result instead:
        // cir.setReturnValue(region);
    }

    private static boolean isRenderThread() {
        return Thread.currentThread().getName().equals("Render thread")
                || Thread.currentThread().getName().equals("Client thread");
    }
}
