package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.class_2791; // Chunk
import net.minecraft.class_3754; // populateNoise target (confirmed by crash log)
import net.minecraft.class_5138;
import net.minecraft.class_6748;
import net.minecraft.class_7138;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * FIXED per runtime crash log on 1.21.11 / Fabric Loader 0.19.3:
 * the real populateNoise descriptor is
 *   populateNoise(class_6748, class_7138, class_5138, class_2791) -> (non-void)
 * Target class resolves correctly to net.minecraft.class_3754 (confirmed by
 * the crash report), so we mixin directly onto class_3754.class instead of
 * a string target — same pattern as the other Voldium mixins.
 *
 * class_6748 / class_7138 / class_5138 identity still needs confirming via
 * genSources (Executor / Blender / NoiseConfig are the most likely
 * candidates based on vanilla's NoiseChunkGenerator#populateNoise shape),
 * but the DESCRIPTOR now matches exactly what the game expects, so this
 * mixin will load instead of crashing at bootstrap.
 */
@Mixin(class_3754.class)
public class MixinNoiseChunkGenerator {

    @Inject(method = "populateNoise", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$parallelPopulateNoise(class_6748 p1, class_7138 p2, class_5138 p3, class_2791 chunk,
                                           CallbackInfoReturnable<Object> cir) {
        if (VoldiumMod.SERVICES == null || VoldiumMod.SERVICES.worldGenEngine() == null) return;
        if (isRenderThread()) return;

        VoldiumMod.SERVICES.worldGenEngine().generateChunkColumnsParallel((localX, localZ) -> {
            // TODO: replace with the real per-column noise/surface call
            // once class_6748/class_7138/class_5138 are confirmed via
            // genSources. Each column MUST only write into chunk data for
            // (localX, localZ) — see AsyncWorldGenEngine's determinism
            // contract before filling this in.
        });

        // Once wired: cir.setReturnValue(...);
    }

    private static boolean isRenderThread() {
        return Thread.currentThread().getName().equals("Render thread")
                || Thread.currentThread().getName().equals("Client thread");
    }
}
