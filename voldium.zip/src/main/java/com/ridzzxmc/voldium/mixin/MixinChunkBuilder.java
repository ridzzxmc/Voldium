package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayDeque;
import java.util.Queue;
import net.minecraft.class_846; // ChunkBuilder

/**
 * NOTE: Class/method names below match roughly-current Yarn intermediary
 * names. Confirm against your actual 1.21.11 mapped sources (Fabric dev
 * env -> genSources) before compiling; method signatures for the
 * "upload finished section" callback shift between snapshots.
 *
 * Strategy unchanged from v1: instead of uploading every ready chunk mesh
 * the instant it's built (GPU upload bursts -> frame spikes crossing
 * chunk borders), queue finished sections and drain a capped number per
 * frame via MixinWorldRenderer#co$drainQueueBeforeRender.
 */
@Mixin(class_846.class)
public class MixinChunkBuilder {

    private final Queue<Runnable> co$pendingUploads = new ArrayDeque<>();

    @Inject(method = "upload*", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$queueUpload(CallbackInfo ci) {
        if (co$pendingUploads.size() >= VoldiumMod.CONFIG.maxChunkUploadsPerFrame) {
            ci.cancel();
        }
    }

    /** Called once per client render tick from MixinWorldRenderer to drain a capped batch. */
    public void co$drainUploads() {
        int budget = VoldiumMod.CONFIG.maxChunkUploadsPerFrame;
        while (budget-- > 0 && !co$pendingUploads.isEmpty()) {
            co$pendingUploads.poll().run();
        }
    }

    public int co$pendingCount() {
        return co$pendingUploads.size();
    }
}
