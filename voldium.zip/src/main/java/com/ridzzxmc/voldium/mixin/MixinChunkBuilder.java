package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.ArrayDeque;
import java.util.Queue;

/**
 * NOTE: Class/method names below match roughly-current Yarn mappings for
 * the 1.20.x/1.21.x ChunkBuilder. Confirm against your actual 1.21.11
 * mappings (Fabric dev env -> genSources) before compiling; method
 * signatures for the "upload finished section" callback shift between
 * snapshots.
 *
 * Strategy: instead of uploading every ready chunk mesh the instant it's
 * built (which causes GPU upload bursts -> frame spikes when crossing
 * chunk borders), we queue finished sections and drain a capped number
 * per frame via a tick hook.
 */
@Mixin(ChunkBuilder.class)
public class MixinChunkBuilder {

    private final Queue<Runnable> co$pendingUploads = new ArrayDeque<>();

    // Pseudocode injection point: adjust @At target to the method that
    // actually performs the VBO/VertexBuffer upload for a finished
    // BuiltChunk section in your mapped ChunkBuilder class.
    @Inject(method = "upload*", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$queueUpload(CallbackInfo ci) {
        if (co$pendingUploads.size() >= VoldiumMod.CONFIG.maxChunkUploadsPerFrame) {
            // Defer: cancel this immediate upload, it'll be retried next
            // drain cycle by the caller re-checking dirty sections.
            ci.cancel();
        }
    }

    /**
     * Call this once per client render tick (hooked from MixinWorldRenderer)
     * to drain a capped batch of queued uploads, spreading GPU work evenly
     * across frames instead of bursting.
     */
    public void co$drainUploads() {
        int budget = VoldiumMod.CONFIG.maxChunkUploadsPerFrame;
        while (budget-- > 0 && !co$pendingUploads.isEmpty()) {
            co$pendingUploads.poll().run();
        }
    }
}
