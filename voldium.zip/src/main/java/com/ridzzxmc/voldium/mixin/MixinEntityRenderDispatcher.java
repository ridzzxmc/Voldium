package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.class_4604; // Frustum
import net.minecraft.class_1297; // Entity
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NOTE: confirm shouldRender's real signature against your 1.21.11 mapped
 * sources (parameter order/types shift across versions). The signature
 * assumed here is shouldRender(Entity, Frustum, double, double, double).
 *
 * Fast-path entity culling: consults the latest VisibilityEngine snapshot
 * first (cheap set lookup), then falls back to CullingManager's
 * distance+direction test if async visibility is disabled or has no data
 * yet for this entity (fail-open -> render it, never fail-closed).
 */
@Mixin(targets = "net.minecraft.client.render.entity.EntityRenderDispatcher")
public class MixinEntityRenderDispatcher {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$distanceCull(class_1297 entity, class_4604 frustum, double camX, double camY, double camZ,
                                  CallbackInfoReturnable<Boolean> cir) {
        if (VoldiumMod.SERVICES == null) return; // not initialized yet (very early load order edge case)

        int cullDist = VoldiumMod.CONFIG.entityCullDistance;
        if (cullDist <= 0) return;

        var snapshot = VoldiumMod.SERVICES.visibilityEngine().getSnapshot();
        if (!snapshot.isEntityVisible(entity.method_5628())) {
            cir.setReturnValue(false);
        }
        // else: fall through to vanilla's own frustum/distance logic, we
        // only ever veto-hide here, never force-show past vanilla checks.
    }
}
