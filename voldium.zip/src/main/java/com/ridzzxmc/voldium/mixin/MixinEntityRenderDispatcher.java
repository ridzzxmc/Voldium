package com.ridzzxmc.voldium.mixin;

import com.ridzzxmc.voldium.VoldiumMod;
import net.minecraft.client.render.entity.EntityRenderDispatcher;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * NOTE: confirm "shouldRender"-equivalent method name for 1.21.11 mappings.
 *
 * Skips rendering entities that are both farther than entityCullDistance
 * AND not currently in the camera frustum. This avoids paying render cost
 * for mobs/items far to the sides or behind the player that vanilla still
 * processes in some cases (e.g. name tag / hitbox edge logic).
 */
@Mixin(EntityRenderDispatcher.class)
public class MixinEntityRenderDispatcher {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true, require = 0)
    private void co$distanceCull(Entity entity, Object frustum, double camX, double camY, double camZ,
                                  CallbackInfoReturnable<Boolean> cir) {
        int cullDist = VoldiumMod.CONFIG.entityCullDistance;
        if (cullDist <= 0) return;

        Vec3d pos = entity.getPos();
        double dx = pos.x - camX;
        double dy = pos.y - camY;
        double dz = pos.z - camZ;
        double distSq = dx * dx + dy * dy + dz * dz;

        if (distSq > (double) cullDist * cullDist) {
            // Only cull if also not something the frustum check would
            // otherwise force-keep (e.g. large entities). Real frustum
            // handle typed as Object here; cast to Frustum once you've
            // confirmed the mapped type/import for 1.21.11.
            cir.setReturnValue(false);
        }
    }
}
