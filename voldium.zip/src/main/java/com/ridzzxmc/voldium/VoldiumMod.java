package com.ridzzxmc.voldium;

import com.ridzzxmc.voldium.client.VoldiumClientEvents;
import com.ridzzxmc.voldium.config.VoldiumConfig;
import com.ridzzxmc.voldium.core.AsyncWorldGenEngine;
import com.ridzzxmc.voldium.core.ChunkOptimizer;
import com.ridzzxmc.voldium.core.VoldiumServices;
import com.ridzzxmc.voldium.culling.CullingManager;
import com.ridzzxmc.voldium.culling.VisibilityEngine;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VoldiumMod implements ClientModInitializer {

    public static final String MOD_ID = "voldium";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static VoldiumConfig CONFIG;
    public static VoldiumServices SERVICES;

    @Override
    public void onInitializeClient() {
        CONFIG = VoldiumConfig.load();

        if (CONFIG.sodiumCompat && CONFIG.vulkanModCompat) {
            LOGGER.warn("[Voldium] Both sodiumCompat and vulkanModCompat are enabled. "
                    + "Only one renderer can be active at runtime. Falling back to auto-detect.");
        }

        boolean sodiumPresent = isModLoaded("sodium");
        boolean vulkanPresent = isModLoaded("vulkanmod");

        if (sodiumPresent && vulkanPresent) {
            LOGGER.error("[Voldium] Both Sodium and VulkanMod jars are present. "
                    + "This will crash or silently break rendering. Remove one of them.");
        } else if (sodiumPresent) {
            LOGGER.info("[Voldium] Detected Sodium. Using vanilla-pipeline-compatible culling hooks.");
        } else if (vulkanPresent) {
            LOGGER.info("[Voldium] Detected VulkanMod. Chunk-builder throttling mixins will "
                    + "no-op where VulkanMod owns the mesh pipeline; only culling/entity/worldgen hooks apply.");
        } else {
            LOGGER.info("[Voldium] Neither Sodium nor VulkanMod detected. Running against vanilla renderer.");
        }

        // --- Wire up services (clean, explicit dependency graph) ---
        ChunkOptimizer chunkOptimizer = new ChunkOptimizer();
        AsyncWorldGenEngine worldGenEngine = new AsyncWorldGenEngine();
        CullingManager cullingManager = new CullingManager();
        VisibilityEngine visibilityEngine = new VisibilityEngine(cullingManager);

        SERVICES = new VoldiumServices(chunkOptimizer, worldGenEngine, cullingManager, visibilityEngine);

        VoldiumClientEvents.register(cullingManager, visibilityEngine);

        Runtime.getRuntime().addShutdownHook(new Thread(SERVICES::shutdown, "Voldium-Shutdown"));

        LOGGER.info("[Voldium] Loaded. maxChunkUploadsPerFrame={}, cullDistanceEntities={}, "
                        + "aggressiveFrustum={}, cullingAggressiveness={}, asyncThreads={}, asyncVisibility={}",
                CONFIG.maxChunkUploadsPerFrame, CONFIG.entityCullDistance, CONFIG.aggressiveFrustumCulling,
                CONFIG.cullingAggressiveness, CONFIG.resolveAsyncThreads(), CONFIG.enableAsyncVisibility);
    }

    private boolean isModLoaded(String id) {
        return FabricLoader.getInstance().isModLoaded(id);
    }
}
