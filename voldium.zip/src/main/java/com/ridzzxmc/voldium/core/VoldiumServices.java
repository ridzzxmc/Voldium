package com.ridzzxmc.voldium.core;

import com.ridzzxmc.voldium.culling.CullingManager;
import com.ridzzxmc.voldium.culling.VisibilityEngine;

/**
 * Bundles the mod's service singletons. A record rather than a bunch of
 * static fields scattered across classes, so dependencies between
 * services (VisibilityEngine needs CullingManager, DebugOverlay needs
 * both, etc.) are constructed explicitly in one place: VoldiumMod's
 * onInitializeClient. Makes the wiring easy to read and, if this ever
 * grows a test suite, easy to substitute fakes for.
 */
public record VoldiumServices(
        ChunkOptimizer chunkOptimizer,
        AsyncWorldGenEngine worldGenEngine,
        CullingManager cullingManager,
        VisibilityEngine visibilityEngine
) {
    public void shutdown() {
        worldGenEngine.shutdown();
        visibilityEngine.shutdown();
    }
}
