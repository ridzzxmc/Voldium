package com.ridzzxmc.voldium.core;

import com.ridzzxmc.voldium.VoldiumMod;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Parallelizes the CPU-heavy, per-column parts of chunk generation
 * (density/noise sampling, surface rule evaluation) without changing
 * world output.
 *
 * DETERMINISM CONTRACT — read this before touching MixinNoiseChunkGenerator:
 *  1. We only ever parallelize across the 16x16 column grid of a SINGLE
 *     chunk. We never split work across chunks, and we never let two
 *     threads write into overlapping output regions.
 *  2. Each task gets its own thread-local density-function / noise-sampler
 *     instance (Minecraft's samplers commonly cache mutable state such as
 *     interpolation buffers and are NOT safe to share across threads).
 *     Column (x,z) always maps to the SAME output array index regardless
 *     of which thread/order it finishes in, so scheduling order cannot
 *     change the result.
 *  3. We never mutate shared RNG state from worker threads. Any Random
 *     instances used for surface decoration must be seeded deterministically
 *     from (structureSeed, chunkX, chunkZ, localX, localZ) — never from a
 *     shared java.util.Random field on the generator.
 *  4. We join all column tasks (invokeAll / CompletableFuture.allOf)
 *     before the calling generation phase is allowed to proceed — no
 *     generation phase may observe a partially-populated chunk.
 * Violating any of these turns "faster worldgen" into "seed-dependent
 * corrupted terrain", so treat this contract as load-bearing.
 */
public final class AsyncWorldGenEngine {

    private final ExecutorService pool;
    private final AtomicLong totalColumnsGenerated = new AtomicLong();
    private final AtomicLong totalChunksGenerated = new AtomicLong();
    private volatile double lastChunkGenMillis = 0;

    public AsyncWorldGenEngine() {
        int threads = VoldiumMod.CONFIG.resolveAsyncThreads();
        AtomicInteger counter = new AtomicInteger();
        this.pool = new ForkJoinPool(
                threads,
                p -> {
                    ForkJoinWorkerThread t = ForkJoinPool.defaultForkJoinWorkerThreadFactory.newThread(p);
                    t.setName("Voldium-WorldGen-" + counter.incrementAndGet());
                    t.setDaemon(true);
                    return t;
                },
                (t, e) -> VoldiumMod.LOGGER.error("[Voldium] worldgen worker uncaught exception", e),
                false
        );
        VoldiumMod.LOGGER.info("[Voldium] AsyncWorldGenEngine started with {} threads", threads);
    }

    /**
     * Functional contract for one column's worth of work. Implementations
     * MUST be self-contained (own sampler instance) and MUST only write to
     * the output slot(s) corresponding to (localX, localZ).
     */
    @FunctionalInterface
    public interface ColumnTask {
        void run(int localX, int localZ);
    }

    /**
     * Runs {@code task} for every column in a 16x16 chunk, splayed across
     * the worker pool, and blocks until all 256 columns are done. Safe to
     * call from the vanilla chunk-generation executor thread (it will just
     * borrow additional worker threads and join), never call this from a
     * Voldium worker thread itself (no nested pool submission).
     */
    public void generateChunkColumnsParallel(ColumnTask task) {
        long start = System.nanoTime();
        try {
            pool.submit(() -> java.util.stream.IntStream.range(0, 256)
                    .parallel()
                    .forEach(i -> {
                        int lx = i & 15;
                        int lz = i >> 4;
                        task.run(lx, lz);
                        totalColumnsGenerated.incrementAndGet();
                    })
            ).get();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            VoldiumMod.LOGGER.error("[Voldium] column task failed, falling back to sequential caller-thread pass", e);
            for (int i = 0; i < 256; i++) task.run(i & 15, i >> 4);
        } finally {
            lastChunkGenMillis = (System.nanoTime() - start) / 1_000_000.0;
            totalChunksGenerated.incrementAndGet();
        }
    }

    /** Fire-and-forget async submit for non-blocking prefetch (e.g. speculative surface builder warmup). */
    public CompletableFuture<Void> submitAsync(Runnable r) {
        return CompletableFuture.runAsync(r, pool);
    }

    public double getLastChunkGenMillis() {
        return lastChunkGenMillis;
    }

    public long getTotalChunksGenerated() {
        return totalChunksGenerated.get();
    }

    public void shutdown() {
        pool.shutdown();
        try {
            if (!pool.awaitTermination(5, TimeUnit.SECONDS)) pool.shutdownNow();
        } catch (InterruptedException e) {
            pool.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}
