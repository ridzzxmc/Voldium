package com.ridzzxmc.voldium.core;

import com.ridzzxmc.voldium.VoldiumMod;
import com.ridzzxmc.voldium.util.ObjectPool;
import net.minecraft.class_2338; // BlockPos
import net.minecraft.class_2338.class_2339; // BlockPos.Mutable

import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Coordinates the client-visible half of the chunk lifecycle:
 * load -> generate(client echo)/receive -> light -> render.
 *
 * Responsibilities:
 *  - Own the heightmap/biome caches (backed by ChunkDataCache).
 *  - Own shared object pools for hot allocation sites (mutable block
 *    positions, scratch long[] arrays for section bitmasks) so mesh
 *    building and culling don't churn the young-gen GC every frame.
 *  - Track lightweight lifecycle stats surfaced by the debug overlay.
 *
 * Thread-safety: pools and caches here are safe to touch from the
 * client worldgen/chunk-load thread(s) AND the render thread. Nothing
 * here does chunk mutation, so there's no risk to server-authoritative
 * state even though "generate" caching also gets warmed from the
 * integrated server thread in singleplayer.
 */
public final class ChunkOptimizer {

    // key: packed chunk long (ChunkPos.toLong()), value: int[16] surface heights per 16x16... etc.
    private final ChunkDataCache<Long, int[]> heightmapCache = new ChunkDataCache<>(1024);
    private final ChunkDataCache<Long, Object> biomeCache = new ChunkDataCache<>(1024);

    public final ObjectPool<class_2339> mutablePosPool =
            new ObjectPool<>(class_2339::new, p -> p.method_10102(0, 0, 0));

    public final ObjectPool<long[]> sectionBitsetScratchPool =
            new ObjectPool<>(() -> new long[64], arr -> java.util.Arrays.fill(arr, 0L));

    private final AtomicInteger chunksLoadedThisSecond = new AtomicInteger();
    private final AtomicLong cacheHits = new AtomicLong();
    private final AtomicLong cacheMisses = new AtomicLong();

    public int[] getOrComputeHeightmap(long chunkPosLong, java.util.function.Supplier<int[]> compute) {
        int[] existing = heightmapCache.get(chunkPosLong);
        if (existing != null) {
            cacheHits.incrementAndGet();
            return existing;
        }
        cacheMisses.incrementAndGet();
        int[] fresh = compute.get();
        heightmapCache.put(chunkPosLong, fresh);
        return fresh;
    }

    public void invalidateChunk(long chunkPosLong) {
        heightmapCache.invalidate(chunkPosLong);
        biomeCache.invalidate(chunkPosLong);
    }

    public void onChunkLoaded() {
        chunksLoadedThisSecond.incrementAndGet();
    }

    public int drainChunksLoadedThisSecond() {
        return chunksLoadedThisSecond.getAndSet(0);
    }

    public long getCacheHits() { return cacheHits.get(); }
    public long getCacheMisses() { return cacheMisses.get(); }
    public int getHeightmapCacheSize() { return heightmapCache.size(); }

    public void clearAll() {
        heightmapCache.clear();
        biomeCache.clear();
        VoldiumMod.LOGGER.info("[Voldium] ChunkOptimizer caches cleared (dimension change / disconnect).");
    }
}
