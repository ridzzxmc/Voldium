package com.ridzzxmc.voldium.core;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 * Bounded LRU cache for per-chunk derived data (heightmaps, biome lookup
 * results) that would otherwise get recomputed repeatedly during the
 * load -> generate -> light -> render lifecycle, or on repeated queries
 * from render/culling code within the same tick.
 *
 * Deliberately a plain synchronized LinkedHashMap(accessOrder=true)
 * behind a read/write lock rather than a fancy concurrent cache library:
 * this mod has no extra dependencies, and chunk cache churn is bursty
 * (batches on chunk load) rather than a hot per-frame path, so lock
 * contention here is a non-issue in practice.
 */
public final class ChunkDataCache<K, V> {

    private final int maxEntries;
    private final ReentrantReadWriteLock lock = new ReentrantReadWriteLock();
    private final LinkedHashMap<K, V> map;

    public ChunkDataCache(int maxEntries) {
        this.maxEntries = maxEntries;
        this.map = new LinkedHashMap<>(256, 0.75f, true) {
            @Override
            protected boolean removeEldestEntry(Map.Entry<K, V> eldest) {
                return size() > ChunkDataCache.this.maxEntries;
            }
        };
    }

    public V get(K key) {
        lock.readLock().lock();
        try {
            return map.get(key);
        } finally {
            lock.readLock().unlock();
        }
    }

    public V computeIfAbsent(K key, java.util.function.Function<K, V> compute) {
        V existing = get(key);
        if (existing != null) return existing;
        V fresh = compute.apply(key);
        put(key, fresh);
        return fresh;
    }

    public void put(K key, V value) {
        lock.writeLock().lock();
        try {
            map.put(key, value);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void invalidate(K key) {
        lock.writeLock().lock();
        try {
            map.remove(key);
        } finally {
            lock.writeLock().unlock();
        }
    }

    public void clear() {
        lock.writeLock().lock();
        try {
            map.clear();
        } finally {
            lock.writeLock().unlock();
        }
    }

    public int size() {
        lock.readLock().lock();
        try {
            return map.size();
        } finally {
            lock.readLock().unlock();
        }
    }
}
