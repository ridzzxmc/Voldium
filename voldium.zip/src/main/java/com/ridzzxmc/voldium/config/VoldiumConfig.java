package com.ridzzxmc.voldium.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Tunable knobs. Defaults are conservative for mid-range mobile GPUs
 * (Mali-G57 / Adreno 505 class hardware).
 */
public class VoldiumConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("voldium.json");

    // --- Renderer selection (pick ONE) ---
    public boolean sodiumCompat = true;
    public boolean vulkanModCompat = false;

    // --- Chunk build / upload throttling ---
    // Caps how many chunk section meshes get uploaded to the GPU per frame.
    // Lower = smoother frametime, higher = faster world pop-in.
    public int maxChunkUploadsPerFrame = 4;

    // Spread chunk rebuilds across N ticks instead of bursting them all
    // when crossing a chunk boundary. This is the main stutter fix.
    public int chunkRebuildSpreadTicks = 3;

    // --- Culling ---
    public boolean aggressiveFrustumCulling = true;
    // Shrinks the frustum test margin (default vanilla padding is generous).
    public float frustumMarginBlocks = 2.0f;

    // Distance-based entity culling (blocks). Entities beyond this AND
    // outside frustum get skipped in the render list entirely.
    public int entityCullDistance = 48;

    // Occlusion-based culling for entities fully behind opaque chunk sections.
    public boolean entityOcclusionCulling = true;

    // --- Frame pacing ---
    // Caches last frame's visible chunk set and reuses it for 1 extra frame
    // when camera movement delta is below this threshold (degrees/tick),
    // avoiding redundant visibility recompute on nearly-static frames.
    public float staticFrameAngleThreshold = 0.5f;

    public static VoldiumConfig load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH)) {
                VoldiumConfig cfg = GSON.fromJson(reader, VoldiumConfig.class);
                if (cfg != null) return cfg;
            } catch (IOException e) {
                // fall through to defaults
            }
        }
        VoldiumConfig defaults = new VoldiumConfig();
        defaults.save();
        return defaults;
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
