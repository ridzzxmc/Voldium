package com.ridzzxmc.voldium.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Tunable knobs. Defaults are conservative for mid-range GPUs.
 *
 * v2.0: added async worldgen thread control, culling aggressiveness presets,
 * the async visibility engine toggle and the debug overlay toggle. Old
 * fields are kept as-is so existing voldium.json files upgrade in place
 * (Gson just leaves new fields at their Java defaults if missing).
 */
public class VoldiumConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance()
            .getConfigDir().resolve("voldium.json");

    public enum CullingAggressiveness { LOW, MEDIUM, HIGH }

    // --- Renderer selection (pick ONE) ---
    public boolean sodiumCompat = true;
    public boolean vulkanModCompat = false;

    // --- Chunk build / upload throttling ---
    public int maxChunkUploadsPerFrame = 4;
    public int chunkRebuildSpreadTicks = 3;

    // --- Culling (legacy fine-grained knobs, still honored) ---
    public boolean aggressiveFrustumCulling = true;
    public float frustumMarginBlocks = 2.0f;
    public int entityCullDistance = 48;
    public boolean entityOcclusionCulling = true;
    public float staticFrameAngleThreshold = 0.5f;

    // --- New: culling aggressiveness preset ---
    // LOW    -> conservative margins, fewer false-negatives, safest visually
    // MEDIUM -> balanced (default)
    // HIGH   -> tighter margins + coarser occlusion sampling, max fps, small
    //           pop-in risk on very fast camera turns
    public CullingAggressiveness cullingAggressiveness = CullingAggressiveness.MEDIUM;

    // --- New: async worldgen / visibility thread pool sizing ---
    // -1 = "auto": Runtime.availableProcessors() - 2, clamped to [1, 6]
    public int asyncThreads = -1;

    // --- New: async visibility engine (main feature) ---
    public boolean enableAsyncVisibility = true;
    // Extra frames a section/entity stays "visible" after the engine marks
    // it hidden, to avoid pop-in/flicker when the PVS snapshot is one tick
    // behind the render thread.
    public int visibilityHysteresisFrames = 2;

    // --- New: debug overlay (F3-style extra line, toggle in config or /voldium debug) ---
    public boolean debugOverlay = false;

    public int resolveAsyncThreads() {
        if (asyncThreads > 0) return asyncThreads;
        int auto = Runtime.getRuntime().availableProcessors() - 2;
        return Math.max(1, Math.min(6, auto));
    }

    public static VoldiumConfig load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH)) {
                VoldiumConfig cfg = GSON.fromJson(reader, VoldiumConfig.class);
                if (cfg != null) {
                    cfg.save(); // rewrite so newly-added fields get persisted
                    return cfg;
                }
            } catch (IOException e) {
                // fall through to defaults
            }
        }
        VoldiumConfig defaults = new VoldiumConfig();
        defaults.save();
        return defaults;
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
