package com.ridzzxmc.voldium.util;

import java.util.Arrays;

/**
 * Fixed-size 4096-bit (16x16x16) bitmask, one bit per block in a chunk
 * section, used to record "potentially visible" blocks after a coarse
 * occlusion pass. Backed by a long[64] so it's cache-friendly (512 bytes,
 * fits in L1) and allocation-free once pooled.
 *
 * Index convention matches vanilla's local section indexing:
 * index = (y << 8) | (z << 4) | x   (x,y,z in [0,16))
 */
public final class SectionVisibilityMask {

    public static final int WORDS = 64; // 4096 bits / 64 bits-per-long

    private final long[] words = new long[WORDS];

    public void clear() {
        Arrays.fill(words, 0L);
    }

    /** Marks everything visible; used as the "no occlusion data yet" fallback so we never over-cull. */
    public void setAllVisible() {
        Arrays.fill(words, -1L); // all bits set
    }

    public void set(int localX, int localY, int localZ) {
        int idx = (localY << 8) | (localZ << 4) | localX;
        words[idx >> 6] |= (1L << (idx & 63));
    }

    public boolean get(int localX, int localY, int localZ) {
        int idx = (localY << 8) | (localZ << 4) | localX;
        return (words[idx >> 6] & (1L << (idx & 63))) != 0L;
    }

    public int popCount() {
        int c = 0;
        for (long w : words) c += Long.bitCount(w);
        return c;
    }

    public void copyFrom(SectionVisibilityMask other) {
        System.arraycopy(other.words, 0, this.words, 0, WORDS);
    }

    public boolean isEmpty() {
        for (long w : words) if (w != 0L) return false;
        return true;
    }
}
