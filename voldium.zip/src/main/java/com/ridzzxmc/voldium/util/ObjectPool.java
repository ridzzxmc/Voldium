package com.ridzzxmc.voldium.util;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Minimal thread-safe object pool. Used anywhere we'd otherwise allocate
 * short-lived, fixed-shape objects every chunk/tick/frame (mutable block
 * positions, double[] heightmap scratch buffers, visibility scratch
 * lists, ...).
 *
 * Not a general-purpose pool: no max-size eviction, because in practice
 * the pool converges to "peak concurrent in-flight objects" and stays
 * there, which is exactly the number you want cached.
 */
public final class ObjectPool<T> {

    private final ConcurrentLinkedQueue<T> pool = new ConcurrentLinkedQueue<>();
    private final Supplier<T> factory;
    private final Consumer<T> reset;

    public ObjectPool(Supplier<T> factory, Consumer<T> reset) {
        this.factory = factory;
        this.reset = reset;
    }

    public T acquire() {
        T obj = pool.poll();
        return obj != null ? obj : factory.get();
    }

    public void release(T obj) {
        if (obj == null) return;
        reset.accept(obj);
        pool.offer(obj);
    }

    /** Convenience for try-with-resources-style scoped use. */
    public Lease<T> lease() {
        return new Lease<>(this, acquire());
    }

    public int size() {
        return pool.size();
    }

    public static final class Lease<T> implements AutoCloseable {
        private final ObjectPool<T> owner;
        public final T value;

        private Lease(ObjectPool<T> owner, T value) {
            this.owner = owner;
            this.value = value;
        }

        @Override
        public void close() {
            owner.release(value);
        }
    }
}
