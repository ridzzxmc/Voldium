package com.ridzz.voldium;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;

/**
 * Voldium — client-side, renderer-agnostic FPS stabilizer.
 *
 * Design goal: NEVER touch chunk rendering, shader, or GPU pipeline code.
 * That's what Sodium / VulkanMod already own. This mod only reads the
 * current FPS and nudges vanilla GameOptions (render distance, particles,
 * entity distance scaling, simulation distance) so the game stays smooth
 * without a manual settings fight. Because it stays out of the renderer
 * entirely, it can't conflict with either Sodium or VulkanMod — it works
 * the same whichever one (or neither) is installed.
 */
public class VoldiumClient implements ClientModInitializer {

	public static final String MOD_ID = "voldium";

	private final FpsStabilizer stabilizer = new FpsStabilizer();

	@Override
	public void onInitializeClient() {
		VoldiumConfig.load();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (!VoldiumConfig.get().enabled) return;
			if (client.world == null || client.player == null) return;
			stabilizer.tick(client);
		});

		VoldiumLog.info("Voldium loaded — target FPS: " + VoldiumConfig.get().targetFps);
	}

	public static MinecraftClient mc() {
		return MinecraftClient.getInstance();
	}
}
