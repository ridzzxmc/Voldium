package com.ridzz.voldium;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.ParticlesMode;
import net.minecraft.client.option.SimpleOption;

/**
 * Watches MinecraftClient#getCurrentFps() and gently steps render distance,
 * simulation distance, particles, and entity distance scaling up or down to
 * hold a target FPS band. Every change is a vanilla GameOptions write, so it
 * is 100% visible/undoable from the normal video settings screen too.
 *
 * NOTE ON MAPPINGS: field/method names below (getViewDistance,
 * getSimulationDistance, getParticles, getEntityDistanceScaling) follow the
 * Yarn naming convention used since ~1.19 and should still apply on
 * 1.21.11, but this version just went through the obfuscated -> unobfuscated
 * mapping transition. If any of these fail to resolve when you build, run
 * `./gradlew genSources` and search GameOptions.java for the equivalent
 * SimpleOption<Integer>/SimpleOption<ParticlesMode> fields — names are very
 * unlikely to have changed meaning, only possibly spelling.
 */
public class FpsStabilizer {

	private static final int CHECK_INTERVAL_TICKS = 40; // ~2 seconds
	private static final int HYSTERESIS = 5; // fps buffer to avoid flip-flopping

	private int tickCounter = 0;
	private int cooldown = 0;

	public void tick(MinecraftClient client) {
		tickCounter++;
		if (cooldown > 0) cooldown--;
		if (tickCounter < CHECK_INTERVAL_TICKS) return;
		tickCounter = 0;
		if (cooldown > 0) return;

		VoldiumConfig.Data cfg = VoldiumConfig.get();
		int currentFps = client.getCurrentFps();
		GameOptions options = client.options;

		if (currentFps < cfg.targetFps - HYSTERESIS) {
			stepDown(options, cfg);
			cooldown = 3; // wait a few checks before adjusting again
		} else if (currentFps > cfg.targetFps + HYSTERESIS + 10) {
			stepUp(options, cfg);
			cooldown = 3;
		}
	}

	private void stepDown(GameOptions options, VoldiumConfig.Data cfg) {
		SimpleOption<Integer> viewDistance = options.getViewDistance();
		SimpleOption<Integer> simDistance = options.getSimulationDistance();
		SimpleOption<Double> entityDistance = options.getEntityDistanceScaling();
		SimpleOption<ParticlesMode> particles = options.getParticles();

		if (viewDistance.getValue() > cfg.minRenderDistance) {
			viewDistance.setValue(viewDistance.getValue() - 1);
			VoldiumLog.info("FPS low, render distance -> " + viewDistance.getValue());
			return;
		}
		if (particles.getValue() != ParticlesMode.MINIMAL) {
			particles.setValue(step(particles.getValue(), -1));
			VoldiumLog.info("FPS low, particles -> " + particles.getValue());
			return;
		}
		if (entityDistance.getValue() > 0.5) {
			entityDistance.setValue(Math.max(0.5, entityDistance.getValue() - 0.25));
			VoldiumLog.info("FPS low, entity distance -> " + entityDistance.getValue());
			return;
		}
		if (simDistance.getValue() > cfg.minSimulationDistance) {
			simDistance.setValue(simDistance.getValue() - 1);
			VoldiumLog.info("FPS low, simulation distance -> " + simDistance.getValue());
		}
	}

	private void stepUp(GameOptions options, VoldiumConfig.Data cfg) {
		SimpleOption<Integer> viewDistance = options.getViewDistance();
		SimpleOption<Integer> simDistance = options.getSimulationDistance();
		SimpleOption<Double> entityDistance = options.getEntityDistanceScaling();
		SimpleOption<ParticlesMode> particles = options.getParticles();

		if (simDistance.getValue() < cfg.maxSimulationDistance) {
			simDistance.setValue(simDistance.getValue() + 1);
			return;
		}
		if (entityDistance.getValue() < 1.0) {
			entityDistance.setValue(Math.min(1.0, entityDistance.getValue() + 0.25));
			return;
		}
		if (particles.getValue() != ParticlesMode.ALL) {
			particles.setValue(step(particles.getValue(), 1));
			return;
		}
		if (viewDistance.getValue() < cfg.maxRenderDistance) {
			viewDistance.setValue(viewDistance.getValue() + 1);
		}
	}

	private ParticlesMode step(ParticlesMode mode, int direction) {
		ParticlesMode[] values = ParticlesMode.values(); // ALL, DECREASED, MINIMAL
		int idx = mode.ordinal() + direction;
		idx = Math.max(0, Math.min(values.length - 1, idx));
		return values[idx];
	}
}
