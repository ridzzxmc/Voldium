package com.ridzz.voldium;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class VoldiumLog {
	private static final Logger LOGGER = LoggerFactory.getLogger("Voldium");

	public static void info(String msg) {
		LOGGER.info(msg);
	}

	public static void error(String msg) {
		LOGGER.error(msg);
	}
}
