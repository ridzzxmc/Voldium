package com.ridzz.voldium;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public class VoldiumConfig {

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance()
			.getConfigDir().resolve("voldium.json");

	private static Data instance;

	public static class Data {
		public boolean enabled = true;
		// Defaults tuned conservatively for mobile GPUs (Mali-G57 / Adreno 505
		// class hardware) — start modest, let the stabilizer step up instead
		// of starting high and immediately chugging.
		public int targetFps = 40;
		public int minRenderDistance = 3;
		public int maxRenderDistance = 8;
		public int minSimulationDistance = 3;
		public int maxSimulationDistance = 8;
	}

	public static Data get() {
		if (instance == null) load();
		return instance;
	}

	public static void load() {
		if (Files.exists(PATH)) {
			try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
				instance = GSON.fromJson(reader, Data.class);
			} catch (IOException e) {
				VoldiumLog.error("Failed to read config, using defaults: " + e.getMessage());
				instance = new Data();
			}
		} else {
			instance = new Data();
			save();
		}
	}

	public static void save() {
		try {
			Files.createDirectories(PATH.getParent());
			try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
				GSON.toJson(instance, writer);
			}
		} catch (IOException e) {
			VoldiumLog.error("Failed to save config: " + e.getMessage());
		}
	}
}
